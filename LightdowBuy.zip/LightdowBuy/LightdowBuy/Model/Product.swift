

import Foundation

struct Product: Codable {
    var productName: String
    var productPrice: String
    var imageUrl: String
    var numberBeenBought: String
    var productDescription: String
   
}

