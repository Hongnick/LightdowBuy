

import Foundation
struct PropertyKeys {
    static let productCell = "product cell"
    static let shoppingcartCell = "shoppingcart cell"
    static let segueToDetail = "segue to detail"
    static let header = "header"
    static let footer = "footer"
    
    static let cart = "cart"
    static let favoriteList = "favoriteList"
    static let shoppingcartController = "ShoppingcartTableViewController"
    static let HomePageCollectionViewCell = ""
 
}
