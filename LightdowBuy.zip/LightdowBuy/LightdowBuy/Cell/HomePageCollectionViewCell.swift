//
//  HomePageCollectionViewCell.swift
//  LightdowBuy
//
//  Created by student on 2021/8/1.
//

import UIKit

class HomePageCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var homePageImg: UIImageView!
//    @IBOutlet weak var homePageControll: UIPageControl!
}
