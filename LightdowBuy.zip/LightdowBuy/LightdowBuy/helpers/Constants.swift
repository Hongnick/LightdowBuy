//
//  Constants.swift
//  LightdowBuy
//
//  Created by student on 2021/7/20.
//

import Foundation

struct Constants {
    
    struct Storyboard {
        
       static let HomePageViewController = "HomeVC"
       static let tabBarController = "HomeVC"
       static let LoginViewController = "LoginVC"
       static let ProductCollectionViewController = "Productlist"
        
    }
}
